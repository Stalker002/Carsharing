﻿namespace Carsharing.Contracts;

public record StatusResponse(
    int Id, 
    string Name, 
    string Description);