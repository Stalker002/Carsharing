﻿namespace Carsharing.Contracts;

public record CategoriesResponse(
    int Id,
    string Name);