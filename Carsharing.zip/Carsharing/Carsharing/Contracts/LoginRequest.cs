﻿namespace Carsharing.Contracts;

public record LoginRequest(
    string Login,
    string Password
);