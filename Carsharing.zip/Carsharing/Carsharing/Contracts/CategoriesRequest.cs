﻿namespace Carsharing.Contracts;

public record CategoriesRequest(
    string Name);