﻿namespace Carsharing.Contracts;

public record StatusRequest(
    string Name,
    string Description);