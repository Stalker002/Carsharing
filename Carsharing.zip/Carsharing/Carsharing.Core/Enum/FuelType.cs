﻿namespace Carsharing.Core.Enum;
public enum FuelType
{
    Бензин,
    Дизель,
    Электро,
    Гибрид,
    Газ
}