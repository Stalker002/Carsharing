﻿using Carsharing.Core.Models;

namespace Carsharing.Core.Abstractions;

public interface IUsersService
{
    Task<string> Login(string login, string password);
    Task<List<User>> GetUsers();
    Task<int> CreateUser(User user);
    Task<int> UpdateUser(int id, int? roleId, string? login, string? passwordHash);
    Task<int> DeleteUser(int id);
}